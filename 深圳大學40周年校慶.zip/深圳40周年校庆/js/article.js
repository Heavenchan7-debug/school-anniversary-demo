var prephone = localStorage.getItem("visartid");
var predate = localStorage.getItem("visartdate");


window.onload=function (){
    init();
    showpremessage();
}

function init(){
    var name = document.getElementById("name");
    var face = document.getElementById("face");
    var id = localStorage.getItem('visartid');
    var m = getusermes(id);
    name.innerText="用户："+m.na;
    face.src=m.face;
}
function getusermes(phone){
    var mes;
    var key = "user";
    if (localStorage.length > 0 && localStorage.getItem(key)) {
        mes = eval(localStorage.getItem(key));
        for (var index in mes) {
            if (mes[index]["Telphone"] === phone) {
                var sig = mes[index]["signature"];
                var na = mes[index]["username"];
                var face = mes[index]["face"];
                return {sig, na, face};
            }
        }
    }
    return "";
}
// 显示草稿图片
function showtmpImg(file) {
    // 将图片文件通过 FileReader 转换并显示在指定容器中
    gettmpImgsByFileReader(document.getElementById("photoContent"), file);
}
// 将草稿图片显示在指定容器中
function gettmpImgsByFileReader(el, files) {
    for (var i = 0; i < files.length; i++) {
        if(!files[i]) return;
        // 创建包含图片和删除按钮的容器 div
        let div = document.createElement('div');
        // div.setAttribute('style','border:2px #00000099; height:130px; display:flex; flex-direction: row; ');
        div.setAttribute('class', 'photo');
        el.appendChild(div);

        // 创建 img 元素用于显示图片
        let img = document.createElement('img');
        // img.setAttribute('style', 'width: 100%; height: 100%;');
        img.setAttribute('class', 'photoStyle');
        div.appendChild(img);
        img.src = files[i];
    }
}
//显示用户信息
function showpremessage(){
    if (localStorage.getItem('nowuser')){
    }else{
        alert("请登录账号！");
        window.location.href="login.html";
        return ;
    }
    var title = document.getElementById("title");
    var mess = document.getElementById("mess");
    var date = document.getElementById("date");
    var name = document.getElementById("author");

    var mes;
    if (localStorage.length > 0 && localStorage.getItem("message")){
        mes = eval(localStorage.getItem("message"));
        jmes = JSON.parse(localStorage.getItem("message"));
        for(var index in mes){
            if (mes[index]["Telphone"] === prephone && JSON.stringify(jmes[index].date) === predate) {
                title.innerText = mes[index]["title"];
                mess.innerText = mes[index]["mess"];
                date.innerText = new Date(JSON.parse(predate)).toLocaleString();
                name.innerText = "作者："+getUsername(prephone);
                showtmpImg(mes[index]["img"]);
                return ;
            }
        }
    }
}
//获取用户昵称
function getUsername(phone){
    var key = "user"
    var mes;
    if (localStorage.length > 0 && localStorage.getItem(key)){
        mes = eval(localStorage.getItem(key));
        for(var index in mes){
            if (mes[index]["Telphone"] === phone) {
                return mes[index]["username"];
            }
        }
    }
    return "";
}
