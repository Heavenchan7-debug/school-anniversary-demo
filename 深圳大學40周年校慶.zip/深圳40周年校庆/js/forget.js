
var code = document.getElementsByClassName('code')[0];
var aEle = document.getElementsByTagName("a")[0];
var userInput = document.getElementById("checkcode");
var confirm = document.getElementsByClassName("btn_sub")[0];
var str1 = "";
window.onload = function () {
    //给表单绑定onclick事件
    conactStr();//初始化验证码
    document.getElementById("btn_sub").onclick = function () {
        if (checkPassword() &&checkRePassword()&&checkEmail() && checkTelphone()&&checkCode()){
            if (checkUser()){
                alert("重置密码成功！");
                window.location.href ="login.html";
            }
            else{
                alert("重置密码失败，请检查是否已注册用户或邮箱是否正确！");
            }
            return true
        }
    };
    //绑定初始化验证码事件
    aEle.onclick=function () {
        aEle.onclick = function () {
            str1="";
            code.innerHTML="";
            conactStr();
        };
    }
    //给密码框、Email、手机号分别绑定离焦事件
    document.getElementById("password").onblur = checkPassword;
    document.getElementById("repassword").onblur = checkRePassword;

    document.getElementById("Email").onblur = checkEmail;
    document.getElementById("Telphone").onblur = checkTelphone;
}

function checkUser(){
    var key = "user"
    var password = document.getElementById("password").value;
    var Email = document.getElementById("Email").value;
    var Telphone = document.getElementById("Telphone").value;

    //加密密码
    password = window.btoa(password);
    var mes;
    if (localStorage.length > 0 && localStorage.getItem(key)){
        mes = eval(localStorage.getItem(key));
        for(var index in mes){
            if (mes[index]["Telphone"] === Telphone) {
                if (mes[index]["Email"] === Email){
                    mes[index]["password"] = password;
                    localStorage.setItem(key, JSON.stringify(mes));
                    return true;
                }
                else return false;
            }
        }
    }
    return false;
}

//校验Email
function checkEmail(){
    //1.获取Email的值
    var email = document.getElementById("Email").value;
    //2.定义正则表达式
    var reg_email = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/;
    //3.判断值是否符合正则的规则
    var flag = reg_email.test(email);
    //4.提示信息
    var s_email = document.getElementById("s_email");

    if(flag){
        //提示绿色对勾
        s_email.innerHTML = "<img width='35' height='25' src='images/gou.png'/>";
    }else{
        //提示红色错误信息
        s_email.innerHTML = "Email格式有误";
    }
    return flag;
}

//校验手机号
function checkTelphone(){
    //1.获取手机号的值
    var telphone = document.getElementById("Telphone").value;
    //2.定义正则表达式
    var reg_telphone = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/;
    //3.判断值是否符合正则的规则
    var flag = reg_telphone.test(telphone);
    //4.提示信息
    var s_telphone = document.getElementById("s_telphone");

    if(flag){
        //提示绿色对勾
        s_telphone.innerHTML = "<img width='35' height='25' src='images/gou.png'/>";
    }else{
        //提示红色错误信息
        s_telphone.innerHTML = "手机号输入有误";
    }
    return flag;
}
//校验密码
function checkPassword(){
    //1.获取密码的值
    var password = document.getElementById("password").value;
    //2.定义正则表达式
    var reg_password = /^\w{6,12}$/;
    //3.判断值是否符合正则的规则
    var flag = reg_password.test(password);
    //4.提示信息
    var s_password = document.getElementById("s_password");

    if(flag){
        //提示绿色对勾
        s_password.innerHTML = "<img width='35' height='25' src='images/gou.png'/>";
    }else{
        //提示红色错误信息
        s_password.innerHTML = "密码格式有误";
    }
    return flag;
}

//校验确认密码
function checkRePassword(){
    //1.获取密码的值
    var password = document.getElementById("password").value;
    var repassword = document.getElementById("repassword").value;

    if(repassword===password && repassword!=""){
        //提示绿色对勾
        s_repassword.innerHTML = "<img width='35' height='25' src='images/gou.png'/>";
        return true
    }else{
        //提示红色错误信息
        s_repassword.innerHTML = "两次密码输入不一致！";
        return false
    }

}

//检验验证码
function checkCode() {
    var userContent = userInput.value;
    console.log(str1.toLowerCase());
    console.log(userContent.toLowerCase());
    if(userContent.toLowerCase()==str1.toLowerCase()){
        userInput.value="";
        return true
    }
    else{
        alert("验证码输入错误！");
        code.innerHTML="";
        str1="";
        conactStr();
        userInput.value="";
        return false
    }
}
//生成随机二维码
function conactStr() {
    var str = "";
    var angle;
    var fontSize = "";
    var marginNum="";
    for (var i = 0; i < 4; i++) {

        for(var j=0;j<6;j++){
            //生成随机颜色
            var pro = Math.random();
            if(pro<0.5){
                str += String.fromCharCode(Math.floor(Math.random() * 6) + 97)
            }else {
                str += Math.floor(Math.random()*10)
            }
        }
        //生成随机角度
        angle = Math.random()<0.5?-Math.random()*20-25:Math.random()*20+25;
        angle = angle%40-20;
        fontSize = Math.floor(Math.random()*10)%5+20+"px";
        marginNum=2+"px";
        str="#"+str;
        var spanEle = document.createElement("span");
        var probability = Math.random();
        if (probability <= 0.33) {
            spanEle.innerHTML =  newChar("num")
        } else if (probability > 0.33 && probability <= 0.66) {
            spanEle.innerHTML =  newChar("smallChar")
        } else {
            spanEle.innerHTML =  newChar("bigChar")
        }
        spanEle.style.transform="rotate("+angle+"deg)";
        spanEle.style.fontSize=fontSize;
        spanEle.style.margin=marginNum+" "+(parseInt(marginNum)+3)+"px 0";
        spanEle.style.fontWeight="bold";
        spanEle.style.lineHeight="30px"
        code.appendChild(spanEle);
        str="";
    }

}

function newChar(flag) {
    var charEle = "";
    if (flag == "num") {
        charEle = String(Math.floor(Math.random() * 10));
    } else if (flag == "smallChar") {
        charEle = String.fromCharCode(Math.floor(Math.random() * 26) + 97)
    } else if (flag == "bigChar") {
        charEle = String.fromCharCode(Math.floor(Math.random() * 26) + 97).toUpperCase()
    }
    str1+=charEle;
    return charEle;
}
