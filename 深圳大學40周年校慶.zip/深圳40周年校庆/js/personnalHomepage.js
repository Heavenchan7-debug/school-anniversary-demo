// 判断是否登录
if (localStorage.getItem('nowuser')){
}
else{
    alert("请登录！");
    window.location.href ="login.html";
}

var id = localStorage.getItem('visituser')?localStorage.getItem('visituser'):localStorage.getItem('nowuser');

init();
showMessage();
showdelbtn();

function init(){
    var name = document.getElementById("name");
    var face = document.getElementById("face");
    var id = localStorage.getItem('visartid');
    var sig = document.getElementById("sig");
    var m = getusermes(id);
    sig.innerText=m.sig;
    name.innerText="用户："+m.na;
    face.src=m.face;

}
function getusermes(phone){
    var mes;
    var key = "user";
    if (localStorage.length > 0 && localStorage.getItem(key)) {
        mes = eval(localStorage.getItem(key));
        for (var index in mes) {
            if (mes[index]["Telphone"] === phone) {
                var sig = mes[index]["signature"];
                var na = mes[index]["username"];
                var face = mes[index]["face"];
                return {sig, na, face};
            }
        }
    }
    return "";
}

//按时间排序
function showMessage() {
    var mesform = document.getElementById("showmessage");
    mesform.innerText = "";

    // 从 localStorage 中获取数据
    var key = "message";
    var data = localStorage.getItem(key);

    // 检查数据是否存在
    if (data) {
        // 将数据解析为数组
        var mess = JSON.parse(data);

        // 对数组进行排序，按照时间降序排列
        mess.sort(function(a, b) {
            return new Date(b.date) - new Date(a.date);
        });

        // 遍历数组中的每个项（倒序遍历）
        for (var index = 0; index < mess.length; index++) {
            var item = mess[index];

            //筛选用户文章
            var messss = mess[index].Telphone;
            if (check(messss, localStorage.getItem("visartid"))) {
            }
            else continue;

            // 创建子 div 元素
            var div = document.createElement('div');
            div.className = 'mesli';
            div.style.display = 'flex';
            div.style.flexWrap = 'nowrap';
            div.style.flexDirection = 'column';

            // 容器，包含username date
            var subDivContainer = document.createElement('div');
            subDivContainer.classList.add("subDivContainer");

            //username
            var subDiv1 = document.createElement('div');
            subDiv1.classList.add('subDiv1');
            subDiv1.innerText = "用户：" + item.username ;

            //date
            var subDiv2 = document.createElement('div');
            subDiv2.classList.add('subDiv2');

            var dateStr = item.date;
            var date = new Date(dateStr);
            var year = date.getFullYear();
            var month = date.getMonth() + 1; // 注意月份索引从0开始，所以需要加1
            var day = date.getDate();

            var formattedDate = year + "-" + (month < 10 ? "0" + month : month) + "-" + (day < 10 ? "0" + day : day);
            subDiv2.innerText = date.toLocaleString();

            //mess
            var subDiv3 = document.createElement('div');
            subDiv3.classList.add('subDiv3');
            subDiv3.innerText = item.mess;

            //titile
            var subDiv4 = document.createElement('div');
            subDiv4.classList.add('subDiv4');
            subDiv4.innerText = item.title;

            // 将子元素添加到父元素
            subDivContainer.appendChild(subDiv1);
            subDivContainer.appendChild(subDiv2);
            var p = item.Telphone ;
            var d = JSON.stringify(item.date);
            const u = {
                p, d,
            }
            //文章详情
            subDiv4.addEventListener('click', gotoHomepage.bind(this, u));

            //deletebnt
            var delbnt = document.createElement('button');
            delbnt.classList.add('delbnt');
            delbnt.style.float="right";
            delbnt.innerText = "删除";
            var vis = localStorage.getItem('visartid');
            var now = localStorage.getItem('nowuser');
            if (now !== vis){
                delbnt.style.display = "none";
            }
            delbnt.addEventListener('click', delmes.bind(this, u));
            subDivContainer.appendChild(delbnt);

            // 将子元素添加到父元素
            div.appendChild(subDiv4);
            div.appendChild(subDiv3);
            div.appendChild(subDivContainer);

            // 将父元素添加到消息容器中
            mesform.appendChild(div);

            // 添加横线
            if (index < mess.length - 1) {
                var hr = document.createElement('hr');
                mesform.appendChild(hr);
            }

            // 添加鼠标悬停样式
            subDiv4.addEventListener('mouseover', function() {
                this.classList.add('subDiv4-hover'); // 添加悬停样式类
            });

            subDiv4.addEventListener('mouseout', function() {
                this.classList.remove('subDiv4-hover'); // 移除悬停样式类
            });
        }
    }
}
function gotoHomepage(u){
    localStorage.setItem("visartid",u.p);
    localStorage.setItem("visartdate",(u.d));
    window.location.href = 'article(comment).html'; // 将页面跳转到相关页面
}
function check(s, str){
    if (s.indexOf(str)!==-1) return true;
}
//删除文章事件
function delmes(u){
    var id = u.p;
    var d = u.d;
    var mes = eval(localStorage.getItem("message"));
    for(var index in mes){
        // alert(mes[index]["Telphone"] +id + JSON.stringify(mes[index].date) + d);
        if (mes[index]["Telphone"] === id && JSON.stringify(mes[index].date) === d) {
            mes.splice(index,1);
            alert("删除成功");
            localStorage.setItem("message", JSON.stringify(mes));
            window.location.href="personnalHomepage.html";
            return;
        }
    }
}
//删除按钮显示
function showdelbtn(){
    var now = localStorage.getItem("nowuser");
    var vis = localStorage.getItem("visartid");
    if (now !== vis ){
        var b = document.getElementsByClassName('delbnt');
        for (var i in b){
            b[i].style.display = "none";
        }
    }
}
