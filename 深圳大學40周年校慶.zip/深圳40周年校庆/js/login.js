
var code = document.getElementsByClassName('code')[0];
var aEle = document.getElementsByTagName("a")[0];
var userInput = document.getElementById("checkcode");
var confirm = document.getElementsByClassName("btn_sub")[0];
var str1 = "";
window.onload = function () {
    function $(ele) {
        return document.querySelector(ele);
    }
    // 初始化账号密码
    isremember();

    document.getElementById("btn_sub").onclick = function () {
        //判断格式
        if (checkUsername() && checkPassword()){
            //记住密码
            localStorage.setItem('preuser', $('#username').value);
            // 首先判断记住密码是否勾选
            if ($('#rememberMe').checked) {
                localStorage.setItem('prepas', window.btoa($('#password').value));
            } else {
                localStorage.removeItem('prepas');
            }
            //检验密码
            if (checkUser()){
                alert("登录成功！");
                localStorage.setItem('nowuser', document.getElementById("username").value)
                window.location.href ="index.html";
            }
            else{
                alert("密码错误或电话号码不存在！");
            }
            return true
        }
    };

    //给密码框、Email/手机号分别绑定离焦事件
    document.getElementById("username").onblur = checkUsername;
    document.getElementById("password").onblur = checkPassword;
}

//记住密码
function isremember(){
    function $(ele) {
        return document.querySelector(ele);
    }

    //加载的时候自动输入用户名
    if (localStorage.getItem('preuser')) {
        $('#username').value = localStorage.getItem('preuser');
    }
    if (localStorage.getItem('prepas')) {
        $('#password').value = window.atob(localStorage.getItem('prepas'));
        $('#rememberMe').checked = true;
    }
}

//校验用户密码
function checkUser(){
    var key = "user"
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    var mes;
    if (localStorage.length > 0 && localStorage.getItem(key)){
        mes = eval(localStorage.getItem(key));
        for(var index in mes){	//由于ps是数组类型, 所以这里的index变量是索引
            if (mes[index]["Telphone"] === username) {
                var pa = window.atob(mes[index]["password"])
                // alert(pa);
                return pa === password;
            }
        }
    }
    return false;
}

//校验手机号
function checkUsername(){
    //1.获取手机号的值
    var telphone = document.getElementById("username").value;
    //2.定义正则表达式
    var reg_telphone = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/;
    //3.判断值是否符合正则的规则
    var flag = reg_telphone.test(telphone);
    //4.提示信息
    var s_telphone = document.getElementById("usernameError");

    if(flag){
        s_telphone.innerHTML = "";
    }else{
        //提示红色错误信息
        s_telphone.innerHTML = "手机号输入有误";
    }
    return flag;
}

//校验密码
function checkPassword(){
    //1.获取密码的值
    var password = document.getElementById("password").value;
    //2.定义正则表达式
    var reg_password = /^\w{6,12}$/;
    //3.判断值是否符合正则的规则
    var flag = reg_password.test(password);
    //4.提示信息
    var s_password = document.getElementById("passwordError");

    if(flag){
        s_password.innerHTML = "";
    }else{
        //提示红色错误信息
        s_password.innerHTML = "密码格式有误";
    }
    return flag;
}
