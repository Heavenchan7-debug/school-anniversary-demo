function $(ele) {
    return document.querySelector(ele);
}
function clear(){
    localStorage.removeItem("message");
    localStorage.removeItem("user");
    localStorage.removeItem("preuser");
    localStorage.removeItem("prepas");
    localStorage.removeItem("visartid");
    localStorage.removeItem("preartdate");
    localStorage.removeItem("preartid");
    localStorage.removeItem("visartdate");
    localStorage.removeItem("nowuser");

}
// clear();


islogin();
document.getElementById("visit_myindex").onclick = gotoMyIndex;

//是否登录
function islogin(){
    function $(ele) {
        return document.querySelector(ele);
    }
    //加载的时候检查用户名
    if (localStorage.getItem('nowuser')) {
        var name = getUsername(localStorage.getItem('nowuser'));

        $('#userface').style = "" +
            "    width: 30px;\n" +
            "    height: 30px;\n" +
            "    border: 1px solid #A4A4A4;\n" +
            "    /* 设置边框为圆角 */\n" +
            "    border-radius: 50px;\n" +
            "    margin: 5px;\n" ;
        $('#userface').src = findUserface();
        $('#userlogin').innerText = "用户："+name;
        $('#userlogin').href = "userface.html";
        $('#userregist').innerText = "注销";
        $('#userregist').href = "index.html";
        $('#userregist').onclick = unload;
    }
    else{
        $('#userface').src = "";
        $('#userface').style = "" ;
        $('#userlogin').href = "login.html";
        $('#userlogin').innerText = "登录";
        $('#userregist').innerText = "注册";
        $('#userregist').href = "regist.html";
    }
}
//获取用户头像
function findUserface(){
    var phone = localStorage.getItem('nowuser');

    var mes;
    var key = "user";
    if (localStorage.length > 0 && localStorage.getItem(key)) {
        mes = eval(localStorage.getItem(key));
        for (var index in mes) {
            if (mes[index]["Telphone"] === phone) {
                // alert(mes[index]["face"]);
                return mes[index]["face"];
            }
        }
    }
    return "";
}
//注销
function unload(){
    if (confirm("确定注销账号吗？")){
        localStorage.removeItem('nowuser');
        localStorage.removeItem('visituser');
        localStorage.removeItem("tmpmess");
        window.location.href ="index.html";
    }else{
        window.location.href ="index.html";
    }
}
//获取用户昵称
function getUsername(phone){
    var key = "user"
    var mes;
    if (localStorage.length > 0 && localStorage.getItem(key)){
        mes = eval(localStorage.getItem(key));
        for(var index in mes){
            if (mes[index]["Telphone"] === phone) {
                return mes[index]["username"];
            }
        }
    }
    return "";
}
function gotoMyIndex(){
    if (localStorage.getItem('nowuser')){
        localStorage.setItem("visartid",localStorage.getItem('nowuser'));
    }

}

// 获取搜索按钮和搜索框元素
var searchButton = document.getElementById("searchbnt");
var searchInput = document.getElementById("search");

// 添加点击事件处理程序
searchButton.addEventListener("click", function() {
    // 获取搜索框的值
    var searchString = searchInput.value;
    // 构建新页面的URL，将搜索关键字作为参数传递
    var newPageURL = "searchPage.html?search=" + encodeURIComponent(searchString);
    // 跳转到新页面
    window.location.href = newPageURL;
});

//搜索比较
function check(s, str){
    if (s.indexOf(str)!==-1) return true;
}

//显示筛搜索信息
function showSearch(searchString) {
    var mesform = document.getElementById("showsearch");
    mesform.innerText = "";

    // 从 localStorage 中获取数据
    var key = "message";
    var data = localStorage.getItem(key);

    // 检查数据是否存在
    if (data) {
        // 将数据解析为数组
        var mess = JSON.parse(data);

        // 对数组进行排序，按照时间降序排列
        mess.sort(function(a, b) {
            return new Date(b.date) - new Date(a.date);
        });

        // 遍历数组中的每个项（倒序遍历）
        for (var index = 0; index < mess.length; index++) {
            var item = mess[index];

            var messageContent = item.mess + item.username + item.title;
            if (check(messageContent,searchString)) {
            }
            else continue;

            // 创建子 div 元素
            var div = document.createElement('div');
            div.className = 'mesli';
            div.style.display = 'flex';
            div.style.flexWrap = 'nowrap';
            div.style.flexDirection = 'column';

            // 容器，包含username date
            var subDivContainer = document.createElement('div');
            subDivContainer.classList.add("subDivContainer");

            //username
            var subDiv1 = document.createElement('div');
            subDiv1.classList.add('subDiv1');
            subDiv1.innerText = "用户：" + item.username ;

            //date
            var subDiv2 = document.createElement('div');
            subDiv2.classList.add('subDiv2');

            var dateStr = item.date;
            var date = new Date(dateStr);
            var year = date.getFullYear();
            var month = date.getMonth() + 1; // 注意月份索引从0开始，所以需要加1
            var day = date.getDate();

            var formattedDate = year + "-" + (month < 10 ? "0" + month : month) + "-" + (day < 10 ? "0" + day : day);
            // subDiv2.innerText = formattedDate;
            subDiv2.innerText = date.toLocaleString();

            //mess
            var subDiv3 = document.createElement('div');
            subDiv3.classList.add('subDiv3');
            subDiv3.innerText = item.mess;


            //titile
            var subDiv4 = document.createElement('div');
            subDiv4.classList.add('subDiv4');
            subDiv4.innerText = item.title;


            // 将子元素添加到父元素
            subDivContainer.appendChild(subDiv1);
            subDivContainer.appendChild(subDiv2);
            var p = item.Telphone ;
            var d = JSON.stringify(item.date);
            const u = {
                p, d,
            }
            //文章详情
            subDiv4.addEventListener('click', gotoHomepage.bind(this, u));

            // 将子元素添加到父元素
            div.appendChild(subDiv4);
            div.appendChild(subDiv3);
            div.appendChild(subDivContainer);

            // 将父元素添加到消息容器中
            mesform.appendChild(div);

            // 添加横线
            if (index < mess.length - 1) {
                var hr = document.createElement('hr');
                mesform.appendChild(hr);
            }

            //用户界面
            subDiv1.addEventListener('click', function() {
                window.location.href = 'index.html'; // 将页面跳转到相关页面
            });


            // 添加鼠标悬停样式
            subDiv4.addEventListener('mouseover', function() {
                this.classList.add('subDiv4-hover'); // 添加悬停样式类
            });

            subDiv4.addEventListener('mouseout', function() {
                this.classList.remove('subDiv4-hover'); // 移除悬停样式类
            });

            subDiv1.addEventListener('mouseover', function() {
                this.classList.add('subDiv1-hover'); // 添加悬停样式类
            });

            subDiv1.addEventListener('mouseout', function() {
                this.classList.remove('subDiv1-hover'); // 移除悬停样式类
            });
        }
    }
}
