init();

window.onload = function () {
    // 判断是否登录
    if (localStorage.getItem('nowuser')){
    }
    else{
        alert("请登录！");
        window.location.href ="login.html";
    }
    if(localStorage.getItem("tmpmess")){
        showtmpmess();
    }
}

// 显示上传的图片
function showImg(obj) {
        var files = obj.files;
        // 将图片文件通过 FileReader 转换并显示在指定容器中
        getImgsByFileReader(document.getElementById("imgcontainer"), files);
}
// 使用 FileReader 将图片文件转换为数据 URL 并显示在指定容器中
function getImgsByFileReader(el, files) {
    for (var i = 0; i < files.length; i++) {
    // 创建包含图片和删除按钮的容器 div
    let div = document.createElement('div');
    div.setAttribute('class', 'innerDiv');
    el.appendChild(div);

    // 创建 img 元素用于显示图片
    let img = document.createElement('img');
    img.setAttribute('class', 'innerImg');
    div.appendChild(img);

    var reader = new FileReader();
    reader.onload = function(e) {
        // 将数据 URL 赋值给 img 元素的 src 属性，显示图片
        img.src = e.target.result;
    }
    // 使用 FileReader 将图片文件转换为数据 URL
    reader.readAsDataURL(files[i]);

    // 创建删除按钮
    let btn = document.createElement('button');
    btn.setAttribute('class', 'innerBtn');
    div.appendChild(btn);

    // 绑定按钮点击事件，点击按钮时移除对应的图片
    btn.onclick = function(){
        div.remove();
    }
    }
}

//提交文章
function submessage(){
    var ret = saveinLocalstorage();
    if(ret){
        alert("提交成功");
        //删除草稿
        deltmpmessage();
        localStorage.setItem("visartid",ret.Telphone);
        localStorage.setItem("visartdate",JSON.stringify(ret.date));
        window.location.href="article(comment).html";
        return true;
    }
}

//预览文章
function premessage(){
    var ret = saveinLocalstorage();
    savtmpmessage();
    if(ret){
        localStorage.setItem("preartid",ret.Telphone);
        localStorage.setItem("preartdate",JSON.stringify(ret.date));
        window.location.href="article_preview.html";
    }

}
function checkill(s){
    var ill = ["jb", "JB", "jB", "Jb"];
    for (var i in ill){
        if (s.indexOf(ill[i]) != -1){
            // alert(ill[i]);
            return true;
        }
    }
    return false;
}

//储存文章到数据库
function saveinLocalstorage(){
    if (localStorage.getItem('nowuser')){
    }else{
        alert("请登录账号！");
        window.location.href="login.html";
        return null;
    }
    var key = "message"
    var title = document.getElementById("title").value;
    var mess = document.getElementById("text2").value;
    var tmpimg = document.getElementsByClassName("innerImg");

    if (checkill(title)||checkill(mess)){
        alert("文章存在敏感词！");
        return null;
    }

    if (mess.length > 1000){
        alert("文章字数应<500!");
        return null;
    }
    else if (mess.length === 0){
        alert("文章字数应>0!");
        return null;
    }
    if (title.length > 40){
        alert("标题字数应<20!");
        return null;
    }
    else if (title.length === 0){
        alert("标题字数应>0!");
        return null;
    }
    var img=[];
    for(var i in tmpimg){
        img.push(tmpimg[i].src);
    }

    var Telphone = localStorage.getItem('nowuser');
    var username = getUsername(Telphone);
    var date = new Date();
    var com = [];
    const newmes = {
        Telphone, username, mess, date, title, img, com,
    }
    var mes;
    if (localStorage.length > 0 && localStorage.getItem(key)){
        mes = eval(localStorage.getItem(key));
        mes.push(newmes);
        localStorage.setItem(key, JSON.stringify(mes));
    }
    else {
        mes = '['+JSON.stringify(newmes)+']';
        localStorage.setItem(key, mes);
    }
    const ret = {
        Telphone, date,
    }
    return ret;
}

//保存草稿
function savtmpmessage(){
    var mess = document.getElementById("text2").value;
    var title = document.getElementById("title").value;
    var tmpimg = document.getElementsByClassName("innerImg");

    var img=[];
    for(var i in tmpimg){
        img.push(tmpimg[i].src);
    }
    const tmpmess = {
        mess, title, img,
    }
    localStorage.setItem("tmpmess", JSON.stringify(tmpmess));
}
//删除草稿 //注销或提交
function deltmpmessage(){
    localStorage.removeItem("tmpmess");
}
//展示草稿
function showtmpmess(){
    var tmpmess = JSON.parse(localStorage.getItem("tmpmess"));
    document.getElementById("title").value = tmpmess.title;
    document.getElementById("text2").value = tmpmess.mess;
    showtmpImg(tmpmess.img);
}
// 显示草稿图片
function showtmpImg(file) {
    // 将图片文件通过 FileReader 转换并显示在指定容器中
    gettmpImgsByFileReader(document.getElementById("imgcontainer"), file);
}
// 将草稿图片显示在指定容器中
function gettmpImgsByFileReader(el, files) {
    for (var i = 0; i < files.length; i++) {
        if(!files[i]) return;
        // 创建包含图片和删除按钮的容器 div
        let div = document.createElement('div');
        div.setAttribute('class', 'innerDiv');
        el.appendChild(div);

        // 创建 img 元素用于显示图片
        let img = document.createElement('img');
        img.setAttribute('class', 'innerImg');
        div.appendChild(img);

        img.src = files[i];

        // 创建删除按钮
        let btn = document.createElement('button');
        btn.setAttribute('class', 'innerBtn');
        div.appendChild(btn);

        // 绑定按钮点击事件，点击按钮时移除对应的图片
        btn.onclick = function(){
            div.remove();
        }
    }
}
function init(){
    var name = document.getElementById("name");
    var id = localStorage.getItem('visituser')?localStorage.getItem('visituser'):localStorage.getItem('nowuser');
    var m = getusermes(id);
    name.innerText="用户："+m.na;
}
function getusermes(phone){
    var mes;
    var key = "user";
    if (localStorage.length > 0 && localStorage.getItem(key)) {
        mes = eval(localStorage.getItem(key));
        for (var index in mes) {
            if (mes[index]["Telphone"] === phone) {
                var sig = mes[index]["signature"];
                var na = mes[index]["username"];
                return {sig, na};
            }
        }
    }
    return "";
}
