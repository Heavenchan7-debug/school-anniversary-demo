var f = document.getElementById("face");
if (localStorage.getItem("visartid")){
    f.src = findUserface(localStorage.getItem("visartid"));
}
else if (localStorage.getItem("nowuser")){
    f.src = findUserface(localStorage.getItem("nowuser"));
}
//获取用户头像
function findUserface(phone){
    var mes;
    var key = "user";
    if (localStorage.length > 0 && localStorage.getItem(key)) {
        mes = eval(localStorage.getItem(key));
        for (var index in mes) {
            if (mes[index]["Telphone"] === phone) {
                return mes[index]["face"];
            }
        }
    }
    return "";
}
