showMessage();

window.onload = function () {
    function $(ele) {
        return document.querySelector(ele);
    }
    //给表单绑定onclick事件
    // 初始化账号
    // islogin();

    document.getElementById("sub").onclick = submessage;
    document.getElementById("sav").onclick = savmessage;
}
//是否登录
function islogin(){
    function $(ele) {
        return document.querySelector(ele);
    }
    // localStorage.removeItem('nowsuer');

    //加载的时候检查用户名
    if (localStorage.getItem('nowuser')) {
        var name = getUsername(localStorage.getItem('nowuser'));

        $('#userface').style = "" +
            "    width: 30px;\n" +
            "    height: 30px;\n" +
            "    border: 1px solid #A4A4A4;\n" +
            "    /* 设置边框为圆角 */\n" +
            "    border-radius: 50px;\n" +
            "    margin: 5px;\n" ;
        $('#userface').src = findUserface();
        $('#userlogin').innerText = "用户："+name;
        $('#userlogin').href = "userface.html";
        $('#userregist').innerText = "注销";
        $('#userregist').href = "index.html";
        $('#userregist').onclick = unload;
        document.getElementById("messageContent").innerText = localStorage.getItem("tmpmess");
    }
    else{
        $('#userface').src = "";
        $('#userface').style = "" ;
        $('#userlogin').href = "login.html";
        $('#userlogin').innerText = "登录";
        $('#userregist').innerText = "注册";
        $('#userregist').href = "regist.html";
        localStorage.removeItem('tmpmess');
    }
}
function findUserface(){
    var phone = localStorage.getItem('nowuser');
    var mes;
    var key = "user";
    if (localStorage.length > 0 && localStorage.getItem(key)) {
        mes = eval(localStorage.getItem(key));
        for (var index in mes) {
            if (mes[index]["Telphone"] === phone) {
                // alert(mes[index]["face"]);
                return mes[index]["face"];
            }
        }
    }
    return "";
}
function unload(){
    if (confirm("确定注销账号吗？")){
        localStorage.removeItem('nowuser');
        window.location.href ="index.html";
    }else{
        window.location.href ="index.html";
    }
}
//获取用户昵称
function getUsername(phone){
    var key = "user"
    var mes;
    if (localStorage.length > 0 && localStorage.getItem(key)){
        mes = eval(localStorage.getItem(key));
        for(var index in mes){
            if (mes[index]["Telphone"] === phone) {
                return mes[index]["username"];
            }
        }
    }
    return "";
}
//提交留言
function submessage(){
    if (localStorage.getItem('nowuser')){
    }else{
        alert("请登录账号！");
        window.location.href="login.html";
        return;
    }
    var key = "message"

    var mess = document.getElementById("messageContent").value;
    if (mess.length > 20){
        alert("留言字数应<20!");
        return;
    }
    var Telphone = localStorage.getItem('nowuser');
    var username = getUsername(Telphone);
    var date = new Date();
    // alert(username);
    const newmes = {
        Telphone, username, mess, date,
    }
    var mes;
    if (localStorage.length > 0 && localStorage.getItem(key)){
        mes = eval(localStorage.getItem(key));
        mes.push(newmes);
        localStorage.setItem(key, JSON.stringify(mes));
    }
    else {
        mes = '['+JSON.stringify(newmes)+']';
        localStorage.setItem(key, mes);
    }
    window.location.href="index.html";
    return true;
}
//保存留言
function savmessage(){
    var key = "tmpmess";
    var mess = document.getElementById("messageContent").value;
    localStorage.setItem(key, mess);
}
//显示信息
function showMessage() {
    var mesform = document.getElementById("showmessage");
    mesform.innerText = "";
    var key = "message";
    // 展示信息
    var mes;
    if (localStorage.length > 0 && localStorage.getItem(key)) {
        mes = eval(localStorage.getItem(key));
        // 获取最新的五个信息
        var latestMes = mes.slice(-5);

        for (var index in latestMes) {
            var username = latestMes[index]["username"];
            var phone = latestMes[index]["title"];
            var mess = latestMes[index]["mess"];
            var date = latestMes[index]["date"];
            var mydate = new Date(date);
            const formatterCN = new Intl.DateTimeFormat('zh-CN', {
                timeZone: 'Asia/Shanghai',
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
            });
            mydate = formatterCN.format(mydate);

            var text1 = phone ;
            var text2 = "用户：" + username ;
            var text3 = "<textarea class='umes' onclick=\"checkuser('" + phone + "','" + date + "','" + index + "')\">" + mess + "</textarea>";
            var div = document.createElement('div');
            div.className = 'mesli';
            div.style.display = 'flex';
            div.style.flexWrap = 'nowrap';
            div.style.flexDirection = 'column';

            var subDiv1 = document.createElement('div');
            subDiv1.classList.add('subDiv1');
            subDiv1.innerText = text1;

            var subDiv2 = document.createElement('div');
            subDiv2.classList.add('subDiv2');
            subDiv2.innerText = text2;

            var subDiv3 = document.createElement('div');
            subDiv3.classList.add('subDiv3');
            subDiv3.innerHTML = text3;

            div.appendChild(subDiv1);
            div.appendChild(subDiv2);
            div.appendChild(subDiv3);

            mesform.appendChild(div);
        }
    }
}
// 左滑按钮点击事件处理函数
function slideLeft() {
    var mesform = document.getElementById("showmessage");
    mesform.scrollTo({
        left: mesform.scrollLeft - mesform.offsetWidth,
        behavior: 'smooth'
    });
}

// 右滑按钮点击事件处理函数
function slideRight() {
    var mesform = document.getElementById("showmessage");
    mesform.scrollTo({
        left: mesform.scrollLeft + mesform.offsetWidth,
        behavior: 'smooth'
    });
}

function checkuser(phone, date, i){
    i = eval(localStorage.getItem("message")).length - i - 1;
    // alert(i);
    if (phone === localStorage.getItem("nowuser")){
        var l = document.getElementsByClassName("umes")[i];
        var b = document.getElementsByClassName("mesbnt")[i];

        l.onblur=function (){
            changemes(phone, date, i);
        }
    }
    else{
        alert("无法修改他人留言！");
        return;
    }
}
function changemes(phone, date, i){
    var l = document.getElementsByClassName("umes")[i].value;
    var key = "message";
    var mes;
    if (localStorage.length > 0 && localStorage.getItem(key)){
        mes = eval(localStorage.getItem(key));
        for(var index in mes){	//由于ps是数组类型, 所以这里的index变量是索引
            if (mes[index]["Telphone"] === phone && mes[index]["date"] === date) {
                mes[index]["mess"] = l;
                break;
            }
        }

        localStorage.setItem(key, JSON.stringify(mes));
    }
}
function delmes(phone, date){
    if (localStorage.getItem("nowuser") !== phone){
        alert("无法修改他人留言！");
        return;
    }
    var key = "message";
    var mes;
    if (localStorage.length > 0 && localStorage.getItem(key)){
        mes = eval(localStorage.getItem(key));
        for(var index in mes){	//由于ps是数组类型, 所以这里的index变量是索引
            if (mes[index]["Telphone"] === phone && mes[index]["date"] === date) {
                // mes.delete(index);
                mes.splice(index,1);
                // return false;
                break;
            }
        }

        localStorage.setItem(key, JSON.stringify(mes));
    }
    window.location.href="index.html";
}
