window.onload = function() {
    islogin();
    showMessage();
    showMessage_rt();
};

//按时间排序
function showMessage() {
    var mesform = document.getElementById("showmessage");
    mesform.innerText = "";

    // 从 localStorage 中获取数据
    var key = "message";
    var data = localStorage.getItem(key);

    // 检查数据是否存在
    if (data) {
        // 将数据解析为数组
        var mess = JSON.parse(data);

        // 对数组进行排序，按照时间降序排列
        mess.sort(function(a, b) {
            return new Date(b.date) - new Date(a.date);
        });

        // 遍历数组中的每个项（倒序遍历）
        for (var index = 0; index < mess.length; index++) {
            var item = mess[index];

            // 创建子 div 元素
            var div = document.createElement('div');
            div.className = 'mesli';
            div.style.display = 'flex';
            div.style.flexWrap = 'nowrap';
            div.style.flexDirection = 'column';

            // 容器，包含username date
            var subDivContainer = document.createElement('div');
            subDivContainer.classList.add("subDivContainer");

            //username
            var subDiv1 = document.createElement('div');
            subDiv1.classList.add('subDiv1');
            subDiv1.innerText = "用户：" + item.username ;

            //date
            var subDiv2 = document.createElement('div');
            subDiv2.classList.add('subDiv2');

            var dateStr = item.date;
            var date = new Date(dateStr);
            var year = date.getFullYear();
            var month = date.getMonth() + 1; // 注意月份索引从0开始，所以需要加1
            var day = date.getDate();

            var formattedDate = year + "-" + (month < 10 ? "0" + month : month) + "-" + (day < 10 ? "0" + day : day);
            subDiv2.innerText = date.toLocaleString();

            //mess
            var subDiv3 = document.createElement('div');
            subDiv3.classList.add('subDiv3');
            subDiv3.innerText = item.mess;


            //titile
            var subDiv4 = document.createElement('div');
            subDiv4.classList.add('subDiv4');
            subDiv4.innerText = item.title;


            // 将子元素添加到父元素
            subDivContainer.appendChild(subDiv1);
            subDivContainer.appendChild(subDiv2);
            var p = item.Telphone ;
            var d = JSON.stringify(item.date);
            const u = {
                p, d,
            }
            //文章详情跳转
            subDiv4.addEventListener('click', gotoHomepage.bind(this, u));

            // 将子元素添加到父元素
            div.appendChild(subDiv4);
            div.appendChild(subDiv3);
            div.appendChild(subDivContainer);

            // 将父元素添加到消息容器中
            mesform.appendChild(div);

            // 添加横线
            if (index < mess.length - 1) {
                var hr = document.createElement('hr');
                mesform.appendChild(hr);
            }

            // 添加鼠标悬停样式
            subDiv4.addEventListener('mouseover', function() {
                this.classList.add('subDiv4-hover'); // 添加悬停样式类
            });

            subDiv4.addEventListener('mouseout', function() {
                this.classList.remove('subDiv4-hover'); // 移除悬停样式类
            });

        }
    }
}
//按字母排序
function showMessage2() {
    var mesform = document.getElementById("showmessage");
    mesform.innerText = "";

    // 从 localStorage 中获取数据
    var key = "message";
    var data = localStorage.getItem(key);

    // 检查数据是否存在
    if (data) {
        // 将数据解析为数组
        var mess1 = eval(data);

        // 对数组进行排序，按照第一个字母（包括汉字）进行升序排列
        mess1.sort(function(a, b) {
            var firstLetterA = a.mess1.charAt(0);
            var firstLetterB = b.mess1.charAt(0);

            if (firstLetterA < firstLetterB) {
                return -1;
            } else if (firstLetterA > firstLetterB) {
                return 1;
            } else {
                return 0;
            }
        });

        // 遍历数组中的每个项
        for (var index = 0; index < mess1.length; index++) {
            var item = mess1[index];

            // 创建子 div 元素
            var div = document.createElement('div');
            div.className = 'mesli';
            div.style.display = 'flex';
            div.style.flexWrap = 'nowrap';
            div.style.flexDirection = 'column';

            // 创建子元素并设置内容
            var subDiv1 = document.createElement('div');
            subDiv1.classList.add('subDiv1');
            subDiv1.innerText = "用户：" + item.username + "的留言";

            var subDiv2 = document.createElement('div');
            subDiv2.classList.add('subDiv2');
            subDiv2.innerText = "留言时间：" + item.date;

            var subDiv3 = document.createElement('div');
            subDiv3.classList.add('subDiv3');
            subDiv3.innerText = item.mess;

            // 将子元素添加到父元素
            div.appendChild(subDiv1);
            div.appendChild(subDiv2);
            div.appendChild(subDiv3);

            // 将父元素添加到消息容器中
            mesform.appendChild(div);
        }
    }
}

function $(ele) {
    return document.querySelector(ele);
}

//是否登录
function islogin(){
    function $(ele) {
        return document.querySelector(ele);
    }
    // localStorage.removeItem('nowsuer');

    //加载的时候检查用户名
    if (localStorage.getItem('nowuser')) {
        var name = getUsername(localStorage.getItem('nowuser'));

        $('#userface').style = "" +
            "    width: 30px;\n" +
            "    height: 30px;\n" +
            "    border: 1px solid #A4A4A4;\n" +
            "    /* 设置边框为圆角 */\n" +
            "    border-radius: 50px;\n" +
            "    margin: 5px;\n" ;
        $('#userface').src = findUserface();
        $('#userlogin').innerText = "用户："+name;
        $('#userlogin').href = "userface.html";
        $('#userregist').innerText = "注销";
        $('#userregist').href = "index.html";
        $('#userregist').onclick = unload;
    }
    else{
        $('#userface').src = "";
        $('#userface').style = "" ;
        $('#userlogin').href = "login.html";
        $('#userlogin').innerText = "登录";
        $('#userregist').innerText = "注册";
        $('#userregist').href = "regist.html";
    }
}
//获取用户头像
function findUserface(){
    var phone = localStorage.getItem('nowuser');
    // alert(phone);
    var mes;
    var key = "user";
    if (localStorage.length > 0 && localStorage.getItem(key)) {
        mes = eval(localStorage.getItem(key));
        for (var index in mes) {
            if (mes[index]["Telphone"] === phone) {
                // alert(mes[index]["face"]);
                return mes[index]["face"];
            }
        }
    }
    return "";
}
//注销
function unload(){
    if (confirm("确定注销账号吗？")){
        localStorage.removeItem('nowuser');
        window.location.href ="index.html";
    }else{
        window.location.href ="index.html";
    }
}
//获取用户昵称
function getUsername(phone){
    var key = "user"
    var mes;
    if (localStorage.length > 0 && localStorage.getItem(key)){
        mes = eval(localStorage.getItem(key));
        for(var index in mes){  //由于ps是数组类型, 所以这里的index变量是索引
            if (mes[index]["Telphone"] === phone) {
                return mes[index]["username"];
            }
        }
    }
    return "";
}

function gotoHomepage(u){
    localStorage.setItem("visartid",u.p);
    localStorage.setItem("visartdate",(u.d));
    window.location.href = 'article(comment).html'; // 将页面跳转到相关页面
}
function check(s, str){
    if (s.indexOf(str)!==-1) return true;
}
console.log("111");

//推荐 只显示标题
function showMessage_rt(){

    var mesform = document.getElementById("showmessage_rt");
    mesform.innerText = "";

    // 从 localStorage 中获取数据
    var key = "message";
    var data = localStorage.getItem(key);

    // 检查数据是否存在
    if (data) {
        // 将数据解析为数组
        var mess = JSON.parse(data);

        // 遍历数组中的每个项，统计com数组的长度
        for (var i = 0; i < mess.length; i++) {
            var item = mess[i];
            item.comCount = item.com ? item.com.length : 0;
            console.log(item.comCount);
        }

        // 对数组进行排序，按照comCount降序排列
        mess.sort(function(a, b) {
            return b.comCount - a.comCount;
        });

        // 只取前五个com最多的mess（如果不足五个则取全部）
        var top5Mess = mess.slice(0, 5);

        // 遍历前五个mess，创建子 div 元素并输出
        for (var index = 0; index < top5Mess.length; index++) {
            var item = top5Mess[index];

            var Title = item.title;

            // 创建子 div 元素
            var div = document.createElement("div");
            div.className = "mesli";
            div.style.display = "flex";
            div.style.flexWrap = "nowrap";
            div.style.flexDirection = "column";

            //titile
            var subDiv4 = document.createElement('div');
            subDiv4.classList.add('subDiv4');
            subDiv4.innerText = item.title || ''; // 添加检查，如果不存在title属性则使用空字符串
            div.appendChild(subDiv4);


            var p = item.Telphone ;
            var d = JSON.stringify(item.date);
            const u = {
                p, d,
            }

            // //文章详情跳转
            subDiv4.addEventListener('click', gotoHomepage.bind(this, u));

            mesform.appendChild(div);
            // 添加横线
            if (index < mess.length - 1) {
                var hr = document.createElement('hr');
                mesform.appendChild(hr);
            }

            // 添加鼠标悬停样式
            subDiv4.addEventListener('mouseover', function() {
                this.classList.add('subDiv4-hover'); // 添加悬停样式类
            });

            subDiv4.addEventListener('mouseout', function() {
                this.classList.remove('subDiv4-hover'); // 移除悬停样式类
            });
        }
    }
}
