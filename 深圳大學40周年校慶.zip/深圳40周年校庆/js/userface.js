
var code = document.getElementsByClassName('code')[0];
var aEle = document.getElementsByTagName("a")[0];
var confirm = document.getElementsByClassName("btn_sub")[0];
// var str1 = "";


inituser();//初始化用户信息
window.onload = function () {
    //给表单绑定onclick事件
    document.getElementById("btn_sub").onclick = function () {
        if (checkUsername() && checkEmail() && checksig()){
            if (storeUser()){
                alert("修改成功！");
                window.location.href ="index.html";
            }
            else
                alert("用户已存在，注册失败");
            return true
        }
    };
    //给用户名和密码框、Email、姓名、手机号分别绑定离焦事件
    document.getElementById("username").onblur = checkUsername;
    document.getElementById("Email").onblur = checkEmail;
    document.getElementById("sig").onblur = checksig;

}
function inituser(){
    var key = "user"
    var Telphone = localStorage.getItem("nowuser");

    var username = document.getElementById("username");
    var Email = document.getElementById("Email");
    var radio = document.getElementsByName("gender");
    var Sex = radio[0];
    var sig = document.getElementById("sig");
    var face = document.getElementById("face");
    if (localStorage.length > 0 && localStorage.getItem(key)){
        mes = eval(localStorage.getItem(key));
        for(var index in mes){	//由于ps是数组类型, 所以这里的index变量是索引
            if (mes[index]["Telphone"] === Telphone) {
                Email.value = mes[index]["Email"];
                username.value = mes[index]["username"];
                Sex.checked = (mes[index]["Sex"] === "男");
                sig.value = mes[index]["signature"];
                face.src = mes[index]["face"];
                break;
            }
        }

    }
}

function storeUser(){
    // var key = "user"
    var username = document.getElementById("username").value;
    var Email = document.getElementById("Email").value;
    var Telphone = localStorage.getItem("nowuser");
    var radio = document.getElementsByName("gender");
    var Sex = radio[0].checked?"男":"女";
    var sig = document.getElementById("sig").value;
    var face = document.getElementById("face");

    var mes;
    var key = "user"
    if (localStorage.length > 0 && localStorage.getItem(key)){
        mes = eval(localStorage.getItem(key));
        for(index in mes){	//由于ps是数组类型, 所以这里的index变量是索引
            if (mes[index]["Telphone"] === Telphone) {
                // alert("ok");
                mes[index]["Email"] = Email;
                mes[index]["Sex"] = Sex;
                mes[index]["username"] = username;
                mes[index]["signature"] = sig;
                mes[index]["face"] = face.src;
                break;
            }
        }

        localStorage.setItem(key, JSON.stringify(mes));
    }

    if (localStorage.length > 0 && localStorage.getItem("message")){
        mes = eval(localStorage.getItem("message"));
        for(var index in mes){
            if (mes[index]["Telphone"] === Telphone) {
                mes[index]["username"] = username;
            }
        }
        localStorage.setItem("message", JSON.stringify(mes));
    }


    return true;
}

//校验用户名
function checkUsername() {
    //获取用户名的值
    var username = document.getElementById("username").value;

    //提示信息
    var s_username = document.getElementById("s_username");

    if (username.length === 0){
        //提示红色错误信息
        s_username.innerHTML = "请输入昵称！";
    } else if (username.length > 6){
        //提示红色错误信息
        s_username.innerHTML = "昵称长度过长！";
    } else{
        //提示绿色对勾
        s_username.innerHTML = "<img src='images/gou.png' width='35' height='25'>";
        return true;
    }
    return false;
}

//校验Email
function checkEmail(){
    //1.获取Email的值
    var email = document.getElementById("Email").value;
    //2.定义正则表达式
    var reg_email = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/;
    //3.判断值是否符合正则的规则
    var flag = reg_email.test(email);
    //4.提示信息
    var s_email = document.getElementById("s_email");

    if(flag){
        //提示绿色对勾
        s_email.innerHTML = "<img width='35' height='25' src='images/gou.png'/>";
    }else{
        //提示红色错误信息
        s_email.innerHTML = "Email格式有误";
    }
    return flag;
}

//校验用户名
function checksig() {
    //获取用户名的值
    var sig = document.getElementById("sig").value;

    //提示信息
    var s_sig = document.getElementById("s_sig");

    if (sig.length > 10){
        //提示红色错误信息
        s_sig.innerHTML = "签名长度过长！";
    } else{
        //提示绿色对勾
        s_sig.innerHTML = "<img src='images/gou.png' width='35' height='25'>";
        return true;
    }
    return false;
}

// 显示上传的图片
function showImg(obj) {
    var files = obj.files;
    // 将图片文件通过 FileReader 转换并显示在指定容器中
    getImgsByFileReader(document.getElementById("face"), files);
}

// 使用 FileReader 将图片文件转换为数据 URL 并显示在指定容器中
function getImgsByFileReader(el, files) {
    for (var i = 0; i < files.length; i++) {

        var reader = new FileReader();
        reader.onload = function(e) {
            // 将数据 URL 赋值给 img 元素的 src 属性，显示图片
            el.src = e.target.result;
        }
        // 使用 FileReader 将图片文件转换为数据 URL
        reader.readAsDataURL(files[i]);
    }
}


