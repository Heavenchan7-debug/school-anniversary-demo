var prephone = localStorage.getItem("preartid");
var predate = localStorage.getItem("preartdate");

//todo预处理后修改文章

showpremessage();

// 显示草稿图片
function showtmpImg(file) {
    // 将图片文件通过 FileReader 转换并显示在指定容器中
    gettmpImgsByFileReader(document.getElementById("photoContent"), file);
}
// 将草稿图片显示在指定容器中
function gettmpImgsByFileReader(el, files) {
    for (var i = 0; i < files.length; i++) {
        if(!files[i]) return;
        // 创建包含图片和删除按钮的容器 div
        let div = document.createElement('div');
        // div.setAttribute('style','border:2px #00000099; height:130px; display:flex; flex-direction: row; ');
        div.setAttribute('class', 'photo');
        el.appendChild(div);

        // 创建 img 元素用于显示图片
        let img = document.createElement('img');
        img.setAttribute('class', 'photoStyle');
        div.appendChild(img);
        img.src = files[i];
    }
}
function showpremessage(){
    if (localStorage.getItem('nowuser')){
    }else{
        alert("请登录账号！");
        window.location.href="login.html";
        return ;
    }

    var title = document.getElementById("title");
    var mess = document.getElementById("mess");
    var date = document.getElementById("date");
    var name = document.getElementById("author");

    var mes;
    if (localStorage.length > 0 && localStorage.getItem("message")){
        mes = eval(localStorage.getItem("message"));
        for(var index in mes){
            if (mes[index]["Telphone"] === prephone && JSON.stringify(mes[index]["date"]) === predate) {
                // alert("find");
                title.innerText = mes[index]["title"];
                mess.innerText = mes[index]["mess"];
                date.innerText = new Date(JSON.parse(predate)).toLocaleString();
                name.innerText = "作者："+getUsername(prephone);
                showtmpImg(mes[index]["img"]);
                return ;
            }
        }
    }

}

function sub(){
    deltmpmessage();
    localStorage.setItem("visartid",localStorage.getItem("preartid"));
    localStorage.setItem("visartdate",localStorage.getItem("preartdate"));
    window.location.href="article(comment).html";
}
//删除草稿 //注销或提交
function deltmpmessage(){
    localStorage.removeItem("tmpmess");
}
function cancel(){
    var key = "message";
    var mes;
    if (localStorage.length > 0 && localStorage.getItem(key)){
        mes = eval(localStorage.getItem(key));
        for(var index in mes){	//由于ps是数组类型, 所以这里的index变量是索引
            if (mes[index]["Telphone"] === prephone && JSON.stringify(mes[index]["date"]) === predate) {
                mes.splice(index,1);
                break;
            }
        }
        localStorage.setItem(key, JSON.stringify(mes));
    }
    window.location.href="publish1.html";
}
