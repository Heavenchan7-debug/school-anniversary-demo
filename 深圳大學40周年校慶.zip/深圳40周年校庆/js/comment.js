var combutton = document.getElementById("combutton");
var cominput = document.getElementById("cominput");
var commentContent = document.getElementById("commentContent");

showComment();
showdelbtn();
function subcomment(){
    if(cominput.value == "")
        alert("请输入内容");
    else{
        let div1 = document.createElement('div');
        div1.setAttribute('style','justify-content: flex-end;width: 80%;height: 150px;display: flex;flex-direction: row;margin-bottom:20px');
        let headimg = document.createElement('div');
        headimg.setAttribute('style','width: 18%;height: 120px;margin-top: 15px;margin-bottom: 15px;margin-left: 20px;');
        div1.appendChild(headimg);
        let imgStyle = document.createElement('img');
        imgStyle.setAttribute('style','width: 100px;\n' +
            '    height: 100px;\n' +
            '    border: 5px solid #A4A4A4aa;\n' +
            '    /* 设置边框为圆角 */\n' +
            '    border-radius: 75px;');
        imgStyle.src = findUserface();
            // "./images/8D1E7518B1998A4BDC4EF812CCB_EADD7E6E_9B795.jpg";
        headimg.appendChild(imgStyle);
        let commentBody = document.createElement('div');
        commentBody.setAttribute('style','width: 70%;height: 120px;margin:15px;');
        div1.appendChild(commentBody);
        let comtop =document.createElement('div');
        comtop.setAttribute('style','width: 100%;height: 30px;display: flex;flex-direction: row;')
        commentBody.appendChild(comtop);
        let comname = document.createElement('div');
        comname.setAttribute('style','width: 40%;height: 30px;');
        let combtn = document.createElement('div');
        combtn.setAttribute('style','width: 10%;height: 30px;margin-left: 30%;');
        let comdate = document.createElement('div');
        comdate.setAttribute('style','width: 20%;height: 30px;');
        comtop.appendChild(comname);
        comtop.appendChild(combtn);
        comtop.appendChild(comdate);
        let combottom =document.createElement('div');
        combottom.setAttribute('style','width: 100%;height: 90px;');
        commentBody.appendChild(combottom);
        var p1 = document.createElement('p');
        var p2 = document.createElement('p');
        var p3 = document.createElement('p');
        p1.setAttribute('style','font-size:20px;text-align:left')
        p2.setAttribute('style','font-size:15px;text-align:left')
        p3.setAttribute('style','font-size:15px;text-align:left')
        comname.appendChild(p1);
        comdate.appendChild(p2);
        combottom.appendChild(p3);

        var d = new Date();
        p1.innerText=getUsername(localStorage.getItem("nowuser"));
        p2.innerText=d.toLocaleString();
        p3.innerText=cominput.value;

        var id = getUsername(localStorage.getItem("nowuser"));
        var d = JSON.stringify(d);
        const u = {
            id, d,
        }

        var delbnt = document.createElement('button');
        delbnt.classList.add('delbnt');
        delbnt.innerText = "删除";
        var now = localStorage.getItem("nowuser");
        var vis = localStorage.getItem("visartid");
        if (now !== vis){
            delbnt.style.display = "none";
        }
        delbnt.addEventListener('click', delcom.bind(this, u));
        combottom.appendChild(delbnt);

        commentContent.appendChild(div1);
        var userid = localStorage.getItem("nowuser");
        var commes = cominput.value;
        var comDate = d;
        var userface = imgStyle.src;
        const com = {
            userid, comDate, commes, userface,
        }
        insertComment(com);
        cominput.value = "";
    }
}
//获取用户头像
function findUserface(){
    var phone = localStorage.getItem('nowuser');
    var mes;
    var key = "user";
    if (localStorage.length > 0 && localStorage.getItem(key)) {
        mes = eval(localStorage.getItem(key));
        for (var index in mes) {
            if (mes[index]["Telphone"] === phone) {
                return mes[index]["face"];
            }
        }
    }
    return "";
}
function insertComment(com){
    var phone = localStorage.getItem('visartid');
    var date = localStorage.getItem('visartdate');

    var mes;
    if (localStorage.length > 0 && localStorage.getItem("message")){
        mes = eval(localStorage.getItem("message"));
        for(var index in mes){
            if (mes[index]["Telphone"] === phone && JSON.stringify(jmes[index].date) === date) {
                mes[index]["com"].push(com);
                alert("评论成功");
                localStorage.setItem("message", JSON.stringify(mes));
                return ;
            }
        }
    }
}
function showComment(){
    var phone = localStorage.getItem('visartid');
    var date = localStorage.getItem('visartdate');
    var comm;
    var mes;
    if (localStorage.length > 0 && localStorage.getItem("message")){
        mes = eval(localStorage.getItem("message"));
        for(var index in mes){
            if (mes[index]["Telphone"] === phone && JSON.stringify(mes[index].date) === date) {
                comm = mes[index]["com"];
                break;
            }
        }
    }
    if(comm.length <= 0){
    }
    else{
        for (var i in comm){
            let div1 = document.createElement('div');
            div1.setAttribute('style','justify-content: flex-end;width: 80%;height: 150px;display: flex;flex-direction: row;margin-bottom:20px');
            div1.className = "wai";
            let headimg = document.createElement('div');
            headimg.setAttribute('style','width: 18%;height: 120px;margin-top: 15px;margin-bottom: 15px;margin-left: 20px;');
            div1.appendChild(headimg);
            let imgStyle = document.createElement('img');
            imgStyle.setAttribute('style','width: 100px;\n' +
                '    height: 100px;\n' +
                '    border: 5px solid #A4A4A4aa;\n' +
                '    /* 设置边框为圆角 */\n' +
                '    border-radius: 75px;');
            imgStyle.src = comm[i].userface;

            headimg.appendChild(imgStyle);
            let commentBody = document.createElement('div');
            commentBody.setAttribute('style','width: 70%;height: 120px;margin:15px;');
            div1.appendChild(commentBody);
            let comtop =document.createElement('div');
            comtop.setAttribute('style','width: 100%;height: 30px;display: flex;flex-direction: row;')
            commentBody.appendChild(comtop);
            let comname = document.createElement('div');
            comname.setAttribute('style','width: 40%;height: 30px;');
            let combtn = document.createElement('div');
            combtn.setAttribute('style','width: 10%;height: 30px;margin-left: 30%;');
            let comdate = document.createElement('div');
            comdate.setAttribute('style','width: 20%;height: 30px;');
            comtop.appendChild(comname);
            comtop.appendChild(combtn);
            comtop.appendChild(comdate);
            let combottom =document.createElement('div');
            combottom.setAttribute('style','width: 100%;height: 90px;');
            commentBody.appendChild(combottom);
            var p1 = document.createElement('p');
            var p2 = document.createElement('p');
            var p3 = document.createElement('p');
            p1.setAttribute('style','font-size:20px;text-align:left')
            p2.setAttribute('style','font-size:15px;text-align:left')
            p3.setAttribute('style','font-size:15px;text-align:left')
            comname.appendChild(p1);
            comdate.appendChild(p2);
            combottom.appendChild(p3);

            p1.innerText=getUsername(comm[i].userid);
            p2.innerText=new Date(comm[i].comDate.substring(1,comm[i].comDate.length-1)).toLocaleString();
            p3.innerText=comm[i].commes;

            var id = comm[i].userid;
            var d = JSON.stringify(comm[i].comDate);
            const u = {
                id, d,
            }
            //deletebnt
            var delbnt = document.createElement('button');
            delbnt.classList.add('delbnt');
            delbnt.innerText = "删除";
            delbnt.addEventListener('click', delcom.bind(this, u));
            combottom.appendChild(delbnt);
            commentContent.appendChild(div1);
        }
    }
}
function getUsername(phone){
    var key = "user"
    var mes;
    if (localStorage.length > 0 && localStorage.getItem(key)){
        mes = eval(localStorage.getItem(key));
        for(var index in mes){
            if (mes[index]["Telphone"] === phone) {
                return mes[index]["username"];
            }
        }
    }
    return "";
}
//删除评论事件
function delcom(u){
    var phone = localStorage.getItem('visartid');
    var date = localStorage.getItem('visartdate');
    var id = u.id;
    var d = u.d;
    var mes = eval(localStorage.getItem("message"));
    for(var index in mes){
        if (mes[index]["Telphone"] === phone && JSON.stringify(mes[index].date) === date) {

            for(var i in mes[index]["com"]){

                if (mes[index]["com"][i].userid === id && JSON.stringify(mes[index]["com"][i].comDate) === d) {

                    mes[index]["com"].splice(i,1);

                    alert("删除成功");
                    localStorage.setItem("message", JSON.stringify(mes));
                    window.location.href="article(comment).html";
                    return;
                }
            }
        }
    }
}
//删除按钮显示
function showdelbtn(){
    var now = localStorage.getItem("nowuser");
    var vis = localStorage.getItem("visartid");
    if (now !== vis ){
        var b = document.getElementsByClassName('delbnt');
        for (var i in b){
            b[i].style.display = "none";
        }
    }
}
